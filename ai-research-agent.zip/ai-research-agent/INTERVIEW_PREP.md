# AI Research Agent - Interview Prep & Resume Guide

---

## Resume Bullet Points

### Project Title (use this exact phrasing)
**AI Research Agent with RAG Pipeline and Multi-turn Dialogue**
`Python | FastAPI | OpenAI API | FAISS | arXiv API`

### Bullets (copy these directly)

- Designed and implemented an end-to-end agentic pipeline that dynamically selects tools (arXiv search, vector retrieval, LLM summarisation) based on user intent classification
- Built a RAG system using OpenAI embeddings and FAISS vector search, with overlapping text chunking to improve retrieval recall across long documents
- Implemented session-based conversation memory with a sliding context window, enabling multi-turn dialogue without exceeding LLM token limits
- Developed async REST API with FastAPI supporting concurrent query handling; structured responses include answer, retrieved sources, and agent reasoning steps
- Architected a modular tool registry pattern, enabling new agent capabilities to be added with minimal code changes

---

## Top 15 Interview Questions & Answers

### 1. Walk me through your project architecture.

**Answer framework:**
"The system has four main layers. First, a FastAPI backend that handles incoming requests asynchronously. Second, an agent planner that analyses the query and decides which tools to run — for example, whether to search arXiv, retrieve from the local vector index, or go directly to the LLM. Third, a RAG retrieval pipeline that chunks documents, embeds them with OpenAI's embedding model, and stores them in FAISS for fast semantic search. Finally, an LLM generation layer that takes the retrieved context plus conversation history and produces the final answer."

**Why this answer works:** Shows you understand the full data flow, not just individual components.

---

### 2. Why did you use RAG instead of just prompting the LLM directly?

**Answer:**
"Three reasons. First, LLMs hallucinate — RAG grounds answers in retrieved evidence, which improves factual accuracy. Second, LLMs have a fixed context window; you can't fit an entire document library into a prompt. RAG lets you retrieve only the relevant chunks. Third, knowledge cutoff — the model's training data is static, but retrieved documents can be current."

---

### 3. What are embeddings and how do you use them?

**Answer:**
"Embeddings convert text into high-dimensional numerical vectors where semantically similar texts are geometrically close. I use OpenAI's text-embedding-3-small model to embed both document chunks during ingestion and the user query at inference time. Then I use FAISS to find the k nearest vectors to the query embedding — those are the most semantically relevant chunks."

---

### 4. How does the agent decide which tool to use?

**Answer:**
"Currently rule-based — I parse the query for intent signals like the words 'paper', 'research', or 'arxiv' and route to the appropriate tool sequence. In a production system I'd replace this with LLM-based planning using function calling or a ReAct prompting pattern, where the model itself reasons about which tools to invoke and in what order."

**Follow-up they might ask:** What is ReAct?
"ReAct stands for Reason + Act. The LLM generates a chain of Thought → Action → Observation steps, which allows it to plan multi-step tool use dynamically."

---

### 5. How did you handle multi-turn conversation?

**Answer:**
"I implemented a session-based memory module that stores conversation turns as a list of {role, content} dicts — the same format as the OpenAI messages API. Each turn appends the user message and assistant response. I apply a sliding window capped at N turns to prevent the history from growing beyond the model's context limit."

---

### 6. What is a context window and why does it matter?

**Answer:**
"The context window is the maximum number of tokens an LLM can process in a single inference call — for GPT-4o it's 128k tokens. It matters for two reasons: cost (more tokens = higher API cost) and quality (models can degrade on very long contexts). My sliding window memory and chunk truncation both help stay within budget."

---

### 7. Why FAISS? Why not Pinecone or Weaviate?

**Answer:**
"For a prototype, FAISS runs in-process with no external dependency, which makes development and testing much faster. It also has sub-millisecond search latency for million-scale indices. For production I'd migrate to a managed vector DB like Pinecone for persistence, multi-tenancy, and horizontal scaling — but FAISS is the right choice to validate the retrieval approach first."

---

### 8. How do you handle large documents?

**Answer:**
"I chunk them into fixed-size overlapping windows. The overlap — I used 64 characters — ensures that context isn't lost when a sentence spans a chunk boundary. I also try to break on sentence boundaries when possible, using the last period position as a split point, which improves chunk coherence and therefore retrieval quality."

---

### 9. What would you do to improve retrieval quality?

**Answer:**
"Three approaches. First, hybrid search — combining BM25 keyword matching with dense vector retrieval, which helps for queries with rare or domain-specific terms. Second, re-ranking — using a cross-encoder model to re-score the initial FAISS results, since cross-encoders are slower but more accurate. Third, query rewriting — having the LLM expand or rephrase the user query before embedding, which surfaces more relevant chunks."

---

### 10. How would you scale this system?

**Answer:**
"Horizontally: run multiple FastAPI worker instances behind a load balancer. For memory: migrate from in-memory dict to Redis, which also supports session expiry. For the vector store: move to Pinecone or a distributed FAISS cluster. For the LLM calls: add a caching layer (e.g. semantic cache using embeddings) to avoid re-calling the API for near-duplicate queries."

---

### 11. What is hallucination and how does your system reduce it?

**Answer:**
"Hallucination is when an LLM generates plausible-sounding but factually incorrect information. My system reduces it through RAG — by injecting retrieved source text into the prompt, the model is anchored to real evidence. I also use a low temperature setting (0.2) in the LLM call to make outputs more deterministic and factual."

---

### 12. How did you test the system?

**Answer:**
"Three levels. Unit tests for individual modules — chunking logic, vector store add/search, memory windowing. Integration tests for the full query → response pipeline using mocked OpenAI responses. And qualitative evaluation: I built a small test set of 20 questions with expected answers, ran the system, and manually evaluated faithfulness and relevance. In production I'd use RAGAS, a framework for automated RAG evaluation."

---

### 13. What challenges did you face?

**Answer (use this structure — specific is better than vague):**
"The main challenge was retrieval quality. Early on the chunks were too large (1000+ chars) and semantically diluted, so the wrong passages kept surfacing. I solved this by reducing chunk size to 512 chars and adding overlap, which significantly improved precision. A secondary challenge was keeping the async code correct — FAISS and arxiv are both blocking libraries, so I had to wrap them in `run_in_executor` to avoid blocking the event loop."

---

### 14. What is prompt engineering?

**Answer:**
"Prompt engineering is designing the input to a language model to reliably elicit the desired output format and quality. In my system I do this in two places: the system prompt, which instructs the model to cite sources and be concise, and the user message construction, where I format the retrieved context before the question to ensure the model grounds its answer in the evidence."

---

### 15. What would you improve next?

**Answer:**
"Two things I'd prioritise. First, an evaluation pipeline using RAGAS to measure faithfulness and answer relevance automatically, so I can iterate on retrieval and prompting with real metrics. Second, multi-agent architecture — separating the planner into a dedicated orchestrator agent and having specialised sub-agents for search, retrieval, and synthesis, which would make the system more modular and capable of handling complex multi-step research tasks."

---

## Terminology Cheat Sheet

| Term | One-line definition |
|---|---|
| RAG | Retrieve relevant docs, inject as context, then generate |
| Embedding | Text → dense vector capturing semantic meaning |
| FAISS | Facebook's library for fast nearest-neighbour search over vectors |
| Chunking | Splitting long docs into smaller pieces for embedding |
| Context window | Max tokens an LLM processes per call |
| Hallucination | LLM generates confident but factually wrong output |
| ReAct | LLM reasoning pattern: Thought → Action → Observation loop |
| Cross-encoder | Re-ranking model that scores query+doc pairs jointly |
| BM25 | Classic keyword-based retrieval (complement to vector search) |
| Temperature | LLM creativity setting: 0 = deterministic, 1 = creative |
