# AI Research Agent

An intelligent research assistant that combines **RAG (Retrieval-Augmented Generation)** with an **agentic planning layer** to answer questions about academic papers.

## Architecture

```
user query
    ↓
FastAPI backend  (async REST API)
    ↓
Agent Planner    (decides: search arXiv? retrieve docs? direct LLM?)
    ↓
Tool Execution   (arXiv search, FAISS retrieval, LLM summarisation)
    ↓
LLM Generation   (GPT-4o-mini with retrieved context + conversation history)
    ↓
structured response (answer + sources + steps_taken)
```

## Project Structure

```
backend/
├── main.py              # FastAPI app entry point
├── api/routes.py        # REST endpoints (/query, /history)
├── agent/
│   ├── planner.py       # Core agent: plans tool execution order
│   └── memory.py        # Multi-turn conversation memory (session-based)
├── tools/
│   ├── arxiv_search.py  # arXiv paper search tool
│   └── summariser.py    # LLM-based summarisation
├── retrieval/
│   ├── chunking.py      # Document chunking with overlap
│   ├── vector_store.py  # FAISS vector index (add, search, persist)
│   └── retriever.py     # Embedding + semantic retrieval pipeline
└── llm/
    └── client.py        # OpenAI API wrapper (chat + embeddings)
```

## Key Technical Decisions

| Decision | Rationale |
|---|---|
| FAISS for vector search | Sub-millisecond search, no external DB dependency for prototype |
| Overlapping chunks | Prevents context loss at chunk boundaries |
| Session-based memory | Sliding window of N turns to stay within context limit |
| Async throughout | Non-blocking IO for concurrent request handling |
| Tool registry pattern | Makes adding new tools a one-line change |

## Setup

```bash
# 1. Clone and install
git clone https://github.com/yourusername/ai-research-agent
cd ai-research-agent
pip install -r requirements.txt

# 2. Set environment variables
cp .env.example .env
# Add your OPENAI_API_KEY to .env

# 3. Run
cd backend
uvicorn main:app --reload
```

## API Usage

```bash
# Ask a research question
curl -X POST http://localhost:8000/api/query \
  -H "Content-Type: application/json" \
  -d '{"query": "What are recent advances in RAG for LLMs?", "session_id": "user123"}'

# Response
{
  "answer": "Recent advances in RAG include...",
  "sources": ["https://arxiv.org/abs/..."],
  "steps_taken": ["search_arxiv", "retrieve_docs", "summarise"],
  "session_id": "user123"
}
```

## Future Improvements

- [ ] Re-ranking retrieved chunks with a cross-encoder model
- [ ] Multi-agent collaboration (planner + researcher + writer agents)
- [ ] Evaluation pipeline with RAGAS metrics (faithfulness, answer relevance)
- [ ] Redis-backed session memory for horizontal scaling
- [ ] Streaming responses via SSE for real-time output
